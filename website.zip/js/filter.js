// ==========================================
// GAMEMARKET - GAME FILTER
// ==========================================

const gameFilter = document.getElementById("gameFilter");
const accountCards = document.querySelectorAll(".account-card");
const filterEmptyState = document.getElementById("emptyState");


// ==========================================
// FUNGSI FILTER GAME
// ==========================================

function filterAccounts(game) {

    let found = 0;

    accountCards.forEach(card => {

        const cardGame = (
            card.dataset.game || ""
        ).toLowerCase();

        if (
            game === "all" ||
            cardGame === game.toLowerCase()
        ) {
            card.style.display = "";
            found++;
        } else {
            card.style.display = "none";
        }

    });


    // Tampilkan empty state
    if (found === 0) {

        filterEmptyState.classList.add("show");

    } else {

        filterEmptyState.classList.remove("show");

    }

}


// ==========================================
// KETIKA FILTER BERUBAH
// ==========================================

if (gameFilter) {

    gameFilter.addEventListener("change", function() {

        filterAccounts(this.value);

    });

}