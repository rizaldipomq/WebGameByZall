// ==========================================
// GAMEMARKET - MAIN APP
// ==========================================


// ==========================================
// ELEMENT
// ==========================================

const modal = document.getElementById("accountModal");
const modalOverlay = document.getElementById("modalOverlay");
const modalClose = document.getElementById("modalClose");

const modalGame = document.getElementById("modalGame");
const modalTitle = document.getElementById("modalTitle");
const modalDescription = document.getElementById("modalDescription");
const modalPrice = document.getElementById("modalPrice");

const detailButtons = document.querySelectorAll(".detail-btn");


// ==========================================
// BUKA DETAIL AKUN
// ==========================================

function openAccountModal(accountId) {

    const account = window.getAccountById(accountId);

    if (!account) {
        return;
    }

    modalGame.textContent = account.game;
    modalTitle.textContent = account.title;
    modalDescription.textContent = account.description;
    modalPrice.textContent = window.formatPrice(account.price);

    modal.classList.add("show");

    document.body.classList.add("modal-open");
}


// ==========================================
// TUTUP MODAL
// ==========================================

function closeAccountModal() {

    modal.classList.remove("show");

    document.body.classList.remove("modal-open");
}


// ==========================================
// TOMBOL DETAIL
// ==========================================

detailButtons.forEach(button => {

    button.addEventListener("click", function() {

        const accountId = this.dataset.id;

        openAccountModal(accountId);

    });

});


// ==========================================
// TOMBOL CLOSE
// ==========================================

if (modalClose) {

    modalClose.addEventListener("click", closeAccountModal);

}


// ==========================================
// KLIK AREA LUAR MODAL
// ==========================================

if (modalOverlay) {

    modalOverlay.addEventListener("click", closeAccountModal);

}


// ==========================================
// TOMBOL ESCAPE
// ==========================================

document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {

        closeAccountModal();

    }

});


// ==========================================
// KATEGORI GAME
// ==========================================

const gameCards = document.querySelectorAll(".game-card");

gameCards.forEach(card => {

    card.addEventListener("click", function() {

        const selectedGame = this.dataset.game;

        if (!selectedGame) {
            return;
        }

        // Ubah dropdown filter
        if (gameFilter) {

            gameFilter.value = selectedGame;

            filterAccounts(selectedGame);

        }

        // Scroll ke daftar akun
        const accountsSection =
            document.getElementById("accounts");

        if (accountsSection) {

            accountsSection.scrollIntoView({
                behavior: "smooth"
            });

        }

    });

});


// ==========================================
// TOMBOL LIHAT AKUN
// ==========================================

const accountsButton =
    document.getElementById("accounts");


// Jika ID accounts adalah tombol,
// scroll ke bagian daftar akun

if (accountsButton) {

    accountsButton.addEventListener("click", function(event) {

        event.preventDefault();

        const accountSection =
            document.getElementById("accounts");

        if (accountSection) {

            accountSection.scrollIntoView({
                behavior: "smooth"
            });

        }

    });

}


// ==========================================
// TOMBOL CONTACT
// ==========================================

const contactButton =
    document.getElementById("contactButton");

if (contactButton) {

    contactButton.addEventListener("click", function() {

        alert(
            "Fitur kontak penjual akan tersedia pada versi berikutnya."
        );

    });

}


// ==========================================
// LOG WEBSITE
// ==========================================

console.log("GameMarket berhasil dimuat.");
console.log(
    "Jumlah akun demo:",
    window.gameAccounts.length
);