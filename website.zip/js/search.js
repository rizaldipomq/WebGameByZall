// ==========================================
// GAMEMARKET - SEARCH SYSTEM
// ==========================================

const searchInput = document.getElementById("searchInput");
const searchButton = document.getElementById("searchButton");
const accountGrid = document.getElementById("accountGrid");
const emptyState = document.getElementById("emptyState");


// ==========================================
// FUNGSI PENCARIAN
// ==========================================

function searchAccounts(keyword) {

    keyword = keyword.toLowerCase().trim();

    const cards = accountGrid.querySelectorAll(".account-card");

    let found = 0;

    cards.forEach(card => {

        const title = (
            card.dataset.title || ""
        ).toLowerCase();

        const game = (
            card.dataset.game || ""
        ).toLowerCase();

        if (
            keyword === "" ||
            title.includes(keyword) ||
            game.includes(keyword)
        ) {
            card.style.display = "";
            found++;
        } else {
            card.style.display = "none";
        }

    });

    // Tampilkan pesan jika tidak ada hasil
    if (found === 0) {
        emptyState.classList.add("show");
    } else {
        emptyState.classList.remove("show");
    }

    // Scroll ke daftar akun
    if (keyword !== "") {
        document.getElementById("accounts").scrollIntoView({
            behavior: "smooth"
        });
    }
}


// ==========================================
// KLIK TOMBOL SEARCH
// ==========================================

if (searchButton) {

    searchButton.addEventListener("click", function() {

        searchAccounts(searchInput.value);

    });

}


// ==========================================
// SEARCH DENGAN ENTER
// ==========================================

if (searchInput) {

    searchInput.addEventListener("keydown", function(event) {

        if (event.key === "Enter") {

            searchAccounts(searchInput.value);

        }

    });

}


// ==========================================
// SEARCH REAL-TIME
// ==========================================

if (searchInput) {

    searchInput.addEventListener("input", function() {

        if (this.value.trim() === "") {

            searchAccounts("");

        }

    });

}