// ==========================================
// GAMEMARKET - DATA AKUN
// Data demo untuk website marketplace
// ==========================================

window.gameAccounts = [
    {
        id: 1,
        game: "FC Mobile",
        title: "FC Mobile OVR 115",
        price: 150000,
        description: "Akun FC Mobile dengan OVR tinggi dan squad yang siap dimainkan.",
        image: "assets/images/fc-mobile-1.jpg"
    },

    {
        id: 2,
        game: "Mobile Legends",
        title: "MLBB Mythic Account",
        price: 200000,
        description: "Akun Mobile Legends dengan banyak hero dan skin.",
        image: "assets/images/ml-1.jpg"
    },

    {
        id: 3,
        game: "PUBG Mobile",
        title: "PUBG Mobile Account",
        price: 175000,
        description: "Akun PUBG Mobile dengan berbagai item dan outfit.",
        image: "assets/images/pubg-1.jpg"
    },

    {
        id: 4,
        game: "Free Fire",
        title: "Free Fire Premium Account",
        price: 125000,
        description: "Akun Free Fire dengan berbagai bundle dan item.",
        image: "assets/images/ff-1.jpg"
    }
];


// ==========================================
// FORMAT HARGA
// ==========================================

window.formatPrice = function(price) {
    return new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency: "IDR",
        maximumFractionDigits: 0
    }).format(price);
};


// ==========================================
// CARI AKUN BERDASARKAN ID
// ==========================================

window.getAccountById = function(id) {
    return window.gameAccounts.find(
        account => account.id === Number(id)
    );
};